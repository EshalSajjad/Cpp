#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void displaygrid(char grid[3][3]){
    cout<<"......Tic-Tac-Toe......"<<endl;
    cout<<"_____________________"<<endl;
    cout<<"|      |      |     |"<<endl;
    cout<<"|  "<<grid[0][0]<<"   "<<"|  "<<grid[0][1]<<"   "<<"|  "<<grid[0][2]<<"  |"<<endl;
    cout<<"___0______1______2___"<<endl;
    cout<<"|      |      |     |"<<endl;
    cout<<"|  "<<grid[1][0]<<"   "<<"|  "<<grid[1][1]<<"   "<<"|  "<<grid[1][2]<<"  |"<<endl;
    cout<<"___3______4______5___"<<endl;
    cout<<"|      |      |     |"<<endl;
    cout<<"|  "<<grid[2][0]<<"   "<<"|  "<<grid[2][1]<<"   "<<"|  "<<grid[2][2]<<"  |"<<endl;
    cout<<"___6______7______8___"<<endl;
}

bool checkifwin(char grid[3][3], char player){
    //Check completed straight lines (rows and columns).
    for(int i= 0; i<3; i++){
        if ((grid[i][0] == player && grid[i][1] == player && grid[i][2] == player) || (grid[0][i] == player && grid[1][i] == player && grid[2][i] == player)){
            return true;
        }
    }
    //Check completed diagonal lines.
    if ((grid[0][0] == player && grid[1][1] == player && grid[2][2] == player) || (grid[0][2] == player && grid[1][1] == player && grid[2][0] == player)){
        return true;
    }
    return false;
}

bool checkiftie(char grid[3][3]){
    for(int i=0; i<3; i++){
        for(int j= 0; j<3; j++){
            if(grid[i][j] == ' '){
                return false;
            }
        }
    }
    return true;
}

void playerturn(char grid[3][3]){
    int turn;
    cout<<"enter turn based on the numbers on the grid: ";
    while(true){
        cin>>turn;
        cout<<endl;
        //so basically in the grid[r][c], row should be equal to the turn/3 and column should be equal to turn%3 to get the correct dimensions.
        if(turn >= 0 && turn <=8){
            if(grid[turn/3][turn%3] == ' '){
                grid[turn/3][turn%3] = 'X';
                break;
            }
            else{
                cout<<"invalid move. try again."<<endl;
            }
        }
        else{
            cout<<"invalid move. try again."<<endl;
        }
    }
}

void compturn(char grid[3][3]){
    //to win or force a draw tic tac toe, there are four strategies: block if other is winning, take the corners, take the edge positions, take the center.(https://en.wikipedia.org/wiki/Tic-tac-toe#Strategy)
    
    //always checking if the next move could potentially be a winning one for the ai
    for(int a= 0; a<3; a++){
        for(int b=0; b<3; b++){
            if(grid[a][b] == ' '){
                grid[a][b] = 'O'; //temp place O to check
                if(checkifwin(grid,'O')){ //keep it O if winning
                    return;
                }
                grid[a][b]=' '; //reset to og if not winning
            }
        }
    }
    
    //block if the player is close to winning
    for(int i= 0; i<3; i++){
        for(int j=0; j<3; j++){
            if(grid[i][j] == ' '){
                grid[i][j] = 'X'; //temp placement to check
                if(checkifwin(grid,'X')){
                    grid[i][j] = 'O'; //if winning, place O
                    return;
                }
                grid[i][j]=' '; //reset to og if not winning
            }
        }
    }
    
    //try to play centre, conrer and edge

    //1. centre position
    if(grid[1][1]== ' '){
        grid[1][1] = 'O';
        return;
    }
    
    //2. corner posiotns
    if(grid[0][0] == ' '){
        grid[0][0] = 'O';
        return;
    }
    if(grid[0][2]== ' '){
        grid[0][2]='O';
        return;
    }
    if(grid[2][0]== ' '){
        grid[2][0]= 'O';
        return;
    }
    if(grid[2][2]== ' '){
        grid[2][2]= 'O';
        return;
    }
    
    //3, remainign edges
    if(grid[0][1] == ' '){
        grid[0][1] = 'O';
        return;
    }
    if(grid[1][2]== ' '){
        grid[1][2]='O';
        return;
    }
    if(grid[1][0]== ' '){
        grid[1][0]= 'O';
        return;
    }
    if(grid[2][1]== ' '){
        grid[2][1]= 'O';
        return;
    }
}

int main(){
    char grid[3][3]= {{' ',' ',' '},{' ',' ',' '}, {' ', ' ', ' '}};
    bool gamecontinues = true;
    while(gamecontinues){
        displaygrid(grid);
        //player's turn.
        playerturn(grid);
        if(checkifwin(grid, 'X')){
            displaygrid(grid);
            cout<<"congrats. you won."<<endl;
            break;
        }
        if(checkiftie(grid)){
            displaygrid(grid);
            cout<<"oh. it's a draw :p"<<endl;
            break;
        }
        
        //ai's turn
        compturn(grid);
        if(checkifwin(grid, 'O')){
            displaygrid(grid);
            cout<<"haha i win!"<<endl;
        }
        if(checkiftie(grid)){
            displaygrid(grid);
            cout<<"oh. it's a draw :p"<<endl;
            break;
        }
    }
    return 0;
}