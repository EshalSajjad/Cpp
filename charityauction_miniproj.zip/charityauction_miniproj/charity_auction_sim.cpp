#include <iostream>
#include <string>
using namespace std;

//Display auction items
void displayitems(string item1, string item2, string item3) {
    cout << "1. " << item1 << endl;
    cout << "2. " << item2 << endl;
    cout << "3. " << item3 << endl << endl;
}

//place bid
void placebid(string &allBids, string &lastBidder, double &highestBid, string current) {
    double bidAmount;
    cout << "Enter your bid amount: ";
    cin >> bidAmount;
    
    if(bidAmount > highestBid){
        highestBid = bidAmount;
        lastBidder = current;
        allBids += current + "_" + to_string(bidAmount) + ", ";
        cout << "Bid placed successfully!" << endl << endl;
    } 
    else{
        cout << "Bid must be higher than the current highest bid." << endl;
    }
}

//show last bid
void showLastBid(string allBids) {
    if(!allBids.empty()){
        size_t lastComma = allBids.find_last_of(',');
        size_t secondLastComma = allBids.find_last_of(',', lastComma - 1);
        string lastBid = (secondLastComma == string::npos) ? allBids.substr(0, lastComma) : allBids.substr(secondLastComma + 2, lastComma - secondLastComma - 2);
        cout << "Last bid: " << lastBid << endl;
    }
    else{
        cout << "No bids placed yet." << endl;
    }
}

//display last bid for item
void displayLastBid(string item, double hbid) {
    if(hbid > 0){
        cout << "Last bid for " << item << " is $" << hbid << endl;
    }
    else{
        cout << "No bids yet for " << item << endl;
    }
}

//show last bidder
void showLastBidder(string lastBidder) {
    if(!lastBidder.empty()){
        cout << "Last bidder was: " << lastBidder << endl;
    }
    else{
        cout << "No bids placed yet." << endl;
    }
}

//display all bids
void showAllBids(string allBids) {
    if(!allBids.empty()){
        cout << "All bids: " << allBids << endl;
    }
    else{
        cout << "No bids placed yet." << endl;
    }
}

int main(){
    //items
    string item1 = "Exclusive Dinner with a Celebrity Chef";
    string item2 = "Signed Memorabilia from a Famous Sports Star";
    string item3 = "Original Artwork by a Renowned Local Artist";

    //data for each
    string allBids1 = "", lastBidder1 = "";
    double hbid1 = 50;

    string allBids2 = "", lastBidder2 = "";
    double hbid2 = 100;

    string allBids3 = "", lastBidder3 = "";
    double hbid3 = 150;

    //users
    string user1, user2;
    cout << "Enter username for User 1: ";
    cin >> user1;
    cout << "Enter username for User 2: ";
    cin >> user2;

    bool contbid = true;
    string current = user1;

    while(contbid){
        int input;
        cout << "Current turn: " << current << endl;
        cout << "1. Display Items" << endl;
        cout << "2. Place a bid" << endl;
        cout << "3. Show last bid" << endl;
        cout << "4. Show last bidder" << endl;
        cout << "5. Deny all bidding" << endl;
        cout << "6. See all bids placed" << endl;
        cout << "Enter your choice: ";
        cin >> input;

        if(input == 1){
            displayitems(item1, item2, item3);
        }
        else if(input == 2){
            int choice;
            cout << "Which item would you like to bid on? ";
            cin >> choice;
            
            if(choice == 1){
                placebid(allBids1, lastBidder1, hbid1, current);
            }
            else if(choice == 2){
                placebid(allBids2, lastBidder2, hbid2, current);
            }
            else if(choice == 3){
                placebid(allBids3, lastBidder3, hbid3, current);
            }
            else{
                cout << "Invalid choice!" << endl;
            }
            //switch users
            if(current == user1){
                current = user2;
            }
            else{
                current = user1;
            }

        }
        else if(input == 3){
            int choice;
            cout << "Choose item to show last bid (1, 2, or 3): ";
            cin >> choice;
            if(choice == 1){
                showLastBid(allBids1);
            }
            else if(choice == 2){
                showLastBid(allBids2);
            }
            else if(choice == 3){
                showLastBid(allBids3);
            }
            else{
                cout << "Invalid item choice!" << endl;
            }
        }
        else if(input == 4){
            int choice;
            cout << "Choose item to show last bidder (1, 2, or 3): ";
            cin >> choice;
            if(choice == 1){
                showLastBidder(lastBidder1);
            }
            else if(choice == 2){
                showLastBidder(lastBidder2);
            }
            else if(choice == 3){
                showLastBidder(lastBidder3);
            }
            else{
                cout << "Invalid item choice!" << endl;
            }
        }
        else if(input == 5){
            cout << current << " has denied from bidding." << endl;
            contbid = false;
        }
        else if(input == 6){
            int choice;
            cout << "Choose item to show all bids (1, 2, or 3): ";
            cin >> choice;
            if(choice == 1){
                showAllBids(allBids1);
            }
            else if(choice == 2){
                showAllBids(allBids2);
            }
            else if(choice == 3){
                showAllBids(allBids3);
            }
            else{
                cout << "Invalid item choice!" << endl;
            }
        }
        else{
            cout << "Invalid option. Try again." << endl;
        }
    }
    return 0;
}