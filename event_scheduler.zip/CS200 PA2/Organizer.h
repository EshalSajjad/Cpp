#include <iostream>
#include "DailySchedule.h"

using namespace std;

class Organizer
{
private:
    DailySchedule* daily_schedules;
    int count;

public:
    Organizer()
    {
        //write your code here
        daily_schedules = nullptr;
        count = 0;
    }

    // {
    //     for(int i = 0; i<count-1; ++i){
    //         for (int j = i+1; j < count;j++){
    //             Date d1 = daily_schedules[i].getDate();
    //             Date d2 = daily_schedules[j].getDate();
    //             if (d2.getYear() < d1.getYear() || 
    //                 (d2.getYear() == d1.getYear() && d2.getMonth() < d1.getMonth()) ||
    //                 (d2.getYear() == d1.getYear() && d2.getMonth() == d1.getMonth() && d2.getDay() < d1.getDay()))}
        //                 DailySchedule temp = daily_schedules[i];
    //                 daily_schedules[i] = daily_schedules[j];
    //                 daily_schedules[j] = temp;
    

    void scheduleEvent(Event e)
    {
        //write your code here
        //checking if theres existing sched for the date
        int i = 0;
        for(i = 0; i<count; i++){
            if((e.getDate().getDay()==daily_schedules[i].getDate().getDay()) && (e.getDate().getMonth()==daily_schedules[i].getDate().getMonth()) && (e.getDate().getYear()==daily_schedules[i].getDate().getYear())){
                //add event to the sched if existing
                daily_schedules[i].scheduleEvent(e);
                return;
            }
        }
        if(i == count){ //shifting the array and temp array for existing sched
            DailySchedule* new_daily_schedules = new DailySchedule[count+1];
            for(int j = 0; j<count; j++){
                new_daily_schedules[j]= daily_schedules[j];
            }
            new_daily_schedules[count]=DailySchedule(e.getDate());
            new_daily_schedules[count].scheduleEvent(e);
            count++; //updating count and replacign the old sched array with a new one
            delete[] daily_schedules; //del old arrayy
            daily_schedules = new_daily_schedules;
        }
        //sortign
        for(int i = 0; i<count-1; i++){
            for(int j = 0; j<(count-i-1); j++){
                // if d1>d2 by comparing y, m and d
                if((daily_schedules[j].getDate().getYear() > daily_schedules[j+1].getDate().getYear()) || ((daily_schedules[j].getDate().getYear() == daily_schedules[j+1].getDate().getYear() && daily_schedules[j].getDate().getMonth() > daily_schedules[j+1].getDate().getMonth())) || ((daily_schedules[j].getDate().getYear() == daily_schedules[j+1].getDate().getYear() && daily_schedules[j].getDate().getMonth() == daily_schedules[j+1].getDate().getMonth() && daily_schedules[j].getDate().getDay() > daily_schedules[j+1].getDate().getDay()))){
                    //swap if not in order
                    DailySchedule temp= daily_schedules[j];
                    daily_schedules[j] = daily_schedules[j+1];
                    daily_schedules[j+1] = temp;
                }
            }
        }
    }

    void printAllSchedules()
    {
        //write your code here
        for (int i= 0; i<count; i++){
            daily_schedules[i].printSchedule();
            cout<<endl<<endl;
        }
    }
};
