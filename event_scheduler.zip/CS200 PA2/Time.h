#include <iostream>
using namespace std;

// Time class template
class Time
{
private:
    int hr, min;

    // Defining functions
public:
    Time(int h, int m)
    {
        //Write your code here
        setHr(h);
        setMin(m);
    }

    Time(): hr(0), min(0) {}

    // Functions to set the time attributes
    void setHr(int h)
    {
        //Write your code here
        if(h>=0 && h<24){
            hr = h;
        }
        else{
            hr=0;
        }
    }

    void setMin(int m)
    {
        //Write your code here
        if(m>= 0 && m<60){
            min = m;
        }
        else{
            min=0;
        }
    }


    // Functions to get the time attributes
    int getHr()
    {
        //Write your code here
        return hr;
    }

    int getMin()
    {
        //Write your code here
        return min;
    }

    // Functions to set the time
    // in the Time class template
    void setTime(int x, int y, int z)
    {
        //Write your code here
        setHr(x);
        setMin(y);
    }

    // Function to print the time
    // in HH:MM:SS format
    void showTime()
    {
        //Write your code here
        if(hr<10){
            cout<<"0"<<hr<<":";
        }
        else{
            cout<<hr<<":";
        }

        if(min<10){
            cout<<"0"<<min<<endl;
        }
        else{
            cout<<min<<endl;
        }
    }

    
    // = Operator overloading to assign the time from one object to another
    Time &operator=(const Time &t)
    {
        if (this != &t)
        {
            hr = t.hr;
            min = t.min;
        }
        return *this;
    }
};