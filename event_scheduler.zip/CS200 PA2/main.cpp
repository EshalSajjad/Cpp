#include <iostream>
#include "Organizer.h"
#include <fstream>
#include <string>
// #include "Date.h"

using namespace std;

int TotalMarks = 0;

const string GREEN = "\033[1;32m";
const string RED = "\033[1;31m";
const string RESET = "\033[0m";

string trim(const string &str)
{
    size_t first = str.find_first_not_of(" \t\r\n");
    if (first == string::npos)
        return ""; // String is all whitespace
    size_t last = str.find_last_not_of(" \t\r\n");
    return str.substr(first, (last - first + 1));
}

bool compareFiles(const string &expectedFile, const string &outputFile)
{
    ifstream expected(expectedFile);
    ifstream output(outputFile);

    if (!expected.is_open() || !output.is_open())
    {
        cout << "Error: One of the files could not be opened." << endl;
        return false;
    }

    string expectedLine, outputLine;
    int lineNumber = 1;
    bool filesMatch = true;

    while (getline(expected, expectedLine) && getline(output, outputLine))
    {
        // Normalize line endings and trim leading/trailing whitespace
        expectedLine = trim(expectedLine);
        outputLine = trim(outputLine);

        if (expectedLine != outputLine)
        {
            filesMatch = false;
            cout << "Difference found on line " << lineNumber << ":\n";
            cout << "Expected: \"" << expectedLine << "\"\n";
            cout << "Output:   \"" << outputLine << "\"\n";
        }
        lineNumber++;
    }

    // Check for any extra lines in either file
    while (getline(expected, expectedLine))
    {
        if (!trim(expectedLine).empty())
        {
            filesMatch = false;
            cout << "Extra line in expected file at line " << lineNumber << ": \"" << expectedLine << "\"\n";
        }
        lineNumber++;
    }
    while (getline(output, outputLine))
    {
        if (!trim(outputLine).empty())
        {
            filesMatch = false;
            cout << "Extra line in output file at line " << lineNumber << ": \"" << outputLine << "\"\n";
        }
        lineNumber++;
    }

    expected.close();
    output.close();

    return filesMatch;
}



void test1()
{
    cout<<"Test Case 1: Testing DailySchedule Implementation."<<endl;

    Date date(4, 8, 2024);
    DailySchedule schedule(date);
    Event cs200("Introduction to Programming", "SSE 201", "Favourite Class", Date(4, 8, 2024), Time(11, 0), Time(12, 50));
    Event cs225("Fundamentals of Computer Systems", "HSS A4", "Binary Numbers etc", Date(4, 8, 2024), Time(14, 50), Time(16, 05));
    Event cs210("Discrete Mathematics", "SDSB B3", "Graph Theory", Date(5, 8, 2024), Time(14, 55), Time(16, 55));
    
    schedule.scheduleEvent(cs200);
    schedule.scheduleEvent(cs210);
    schedule.scheduleEvent(cs225);

    // Printing all schedules to verify they are sorted by date
    ofstream outputFile("student_output.txt");
    streambuf *coutbuf = cout.rdbuf(); // Save old buf
    cout.rdbuf(outputFile.rdbuf());    // Redirect cout to file

    // Printing all schedules to verify they are sorted by date
    schedule.printSchedule();

    cout.rdbuf(coutbuf); // Reset to standard output
    outputFile.close();

    bool marks = compareFiles("student_output.txt", "test01.txt");

    if (marks)
    {
        cout << GREEN << "Output matches the expected result. Marks: 10/10" << RESET << endl;
        TotalMarks += 10;
    }
    else
    {
        cout << RED << "Output does not match the expected result. Marks: 0/10" << RESET << endl;
    }


    return;
}

void test2()
{
    cout<<"Test Case 2: Testing Conflict Detection."<<endl;

    Date date(4, 8, 2024);
    DailySchedule schedule(date);
    Event cs200("Introduction to Programming", "SSE 201", "Favourite Class", Date(4, 8, 2024), Time(10, 55), Time(12, 55));
    Event cs225("Fundamentals of Computer Systems", "HSS A4", "Binary Numbers etc", Date(4, 8, 2024), Time(11, 30), Time(13, 45));
    Event cs210("Discrete Mathematics", "SDSB B3", "Graph Theory", Date(4, 8, 2024), Time(14, 55), Time(16, 55));
    Event math102("Calculus II", "SAHSOL CR-106", "Just Integration and more Integration", Date(4, 8, 2024), Time(14, 50), Time(15, 50));
    
    schedule.scheduleEvent(cs200);
    schedule.scheduleEvent(cs210);
    schedule.scheduleEvent(cs225);
    schedule.scheduleEvent(math102);

    // Printing all schedules to verify they are sorted by date
    ofstream outputFile("student_output.txt");
    streambuf *coutbuf = cout.rdbuf(); // Save old buf
    cout.rdbuf(outputFile.rdbuf());    // Redirect cout to file

    // Printing all schedules to verify they are sorted by date
    schedule.printSchedule();

    cout.rdbuf(coutbuf); // Reset to standard output
    outputFile.close();

    bool marks = compareFiles("student_output.txt", "test02.txt");

    if (marks)
    {
        cout << GREEN << "Output matches the expected result. Marks: 20/20" << RESET << endl;
        TotalMarks += 20;
    }
    else
    {
        cout << RED << "Output does not match the expected result. Marks: 0/20" << RESET << endl;
    }


    return;
}

void test3()
{
    cout<<"Test Case 3: Testing Sorting."<<endl;

    Date date(4, 8, 2024);
    DailySchedule schedule(date);
    Event cs200("Introduction to Programming", "SSE 201", "Favourite Class", Date(4, 8, 2024), Time(10, 55), Time(12, 55));
    Event cs225("Fundamentals of Computer Systems", "HSS A4", "Binary Numbers etc", Date(4, 8, 2024), Time(13, 15), Time(14, 30));
    Event cs210("Discrete Mathematics", "SDSB B3", "Graph Theory", Date(4, 8, 2024), Time(14, 45), Time(16, 15));
    Event math102("Calculus II", "SAHSOL CR-106", "Just Integration and more Integration", Date(4, 8, 2024), Time(16, 30), Time(17, 45));
    
    schedule.scheduleEvent(math102);
    schedule.scheduleEvent(cs210);
    schedule.scheduleEvent(cs225);
    schedule.scheduleEvent(cs200);

    // Printing all schedules to verify they are sorted by date
    ofstream outputFile("student_output.txt");
    streambuf *coutbuf = cout.rdbuf(); // Save old buf
    cout.rdbuf(outputFile.rdbuf());    // Redirect cout to file

    // Printing all schedules to verify they are sorted by date
    schedule.printSchedule();

    cout.rdbuf(coutbuf); // Reset to standard output
    outputFile.close();

    bool marks = compareFiles("student_output.txt", "test03.txt");

    if (marks)
    {
        cout << GREEN << "Output matches the expected result. Marks: 20/20" << RESET << endl;
        TotalMarks += 20;
    }
    else
    {
        cout << RED << "Output does not match the expected result. Marks: 0/20" << RESET << endl;
    }


    return;
}

void test4()
{
    cout<<"Test Case 4: Testing Organizer."<<endl;
    
    Organizer organizer;

    // Creating events with different dates
    Event cs200("Introduction to Programming", "SSE 201", "Favourite Class", Date(4, 8, 2024), Time(11, 0), Time(12, 50));
    Event cs225("Fundamentals of Computer Systems", "HSS A4", "Binary Numbers etc", Date(5, 8, 2024), Time(11, 30), Time(13, 45));
    Event cs210("Discrete Mathematics", "SDSB B3", "Graph Theory", Date(4, 8, 2024), Time(12, 15), Time(16, 30));
    Event graduation("Graduation Day", "Cricket Ground", "Azadi from University!!!", Date(15, 5, 2027), Time(8, 55), Time(10, 55));
    Event wedding("Someone's Wedding", "Qasr-E-Noor", "I dont even know who it is.", Date(15, 3, 2022), Time(11, 55), Time(13, 55));

    // Scheduling the events
    organizer.scheduleEvent(wedding);
    organizer.scheduleEvent(cs200);
    organizer.scheduleEvent(cs210);
    organizer.scheduleEvent(cs225);
    organizer.scheduleEvent(graduation);
    

    // Printing all schedules to verify they are sorted by date
    ofstream outputFile("student_output.txt");
    streambuf *coutbuf = cout.rdbuf(); // Save old buf
    cout.rdbuf(outputFile.rdbuf());    // Redirect cout to file

    // Printing all schedules to verify they are sorted by date
    organizer.printAllSchedules();

    cout.rdbuf(coutbuf); // Reset to standard output
    outputFile.close();

    bool marks = compareFiles("student_output.txt", "test04.txt");

    if (marks)
    {
        cout << GREEN << "Output matches the expected result. Marks: 25/25" << RESET << endl;
        TotalMarks += 25;
    }
    else
    {
        cout << RED << "Output does not match the expected result. Marks: 0/25" << RESET << endl;
    }


    return;
}

void test5()
{
    cout<<"Test Case 5: Testing Everything."<<endl;
    
    Organizer organizer;

    // Creating events with different dates
    Event cs200("Introduction to Programming", "SSE 201", "Favourite Class", Date(4, 8, 2024), Time(11, 0), Time(12, 50));
    Event cs225("Fundamentals of Computer Systems", "HSS A4", "Binary Numbers etc", Date(5, 8, 2024), Time(11, 30), Time(13, 45));
    Event cs210("Discrete Mathematics", "SDSB B3", "Graph Theory", Date(4, 8, 2024), Time(12, 15), Time(16, 30));
    Event graduation("Graduation Day", "Cricket Ground", "Azadi from University!!!", Date(15, 5, 2027), Time(8, 55), Time(10, 55));
    Event wedding("Someone's Wedding", "Qasr-E-Noor", "I dont even know who it is.", Date(15, 3, 2022), Time(11, 55), Time(13, 55));
    Event hackathon("Hackathon", "SSE Building", "24-hour coding competition", Date(4, 8, 2024), Time(15, 0), Time(18, 0));
    Event dinner("Family Dinner", "Home", "Dinner with family", Date(4, 8, 2024), Time(19, 0), Time(21, 0));
    Event seminar("AI Seminar", "Library Hall", "Discussion on AI advancements", Date(5, 8, 2024), Time(10, 0), Time(12, 0));
    Event projectMeeting("Project Meeting", "SSE 301", "Final year project discussion", Date(5, 8, 2024), Time(9, 0), Time(12, 0));
    Event holiday("Public Holiday", "Home", "Relaxing at home", Date(14, 8, 2025), Time(0, 0), Time(23, 59));

    // Scheduling the events
    organizer.scheduleEvent(wedding);
    organizer.scheduleEvent(cs200);
    organizer.scheduleEvent(cs225);
    organizer.scheduleEvent(cs210);
    organizer.scheduleEvent(graduation);
    organizer.scheduleEvent(hackathon);
    organizer.scheduleEvent(dinner);
    organizer.scheduleEvent(seminar);
    organizer.scheduleEvent(projectMeeting);
    organizer.scheduleEvent(holiday);
    

    // Printing all schedules to verify they are sorted by date
    ofstream outputFile("student_output.txt");
    streambuf *coutbuf = cout.rdbuf(); // Save old buf
    cout.rdbuf(outputFile.rdbuf());    // Redirect cout to file

    // Printing all schedules to verify they are sorted by date
    organizer.printAllSchedules();

    cout.rdbuf(coutbuf); // Reset to standard output
    outputFile.close();

    bool marks = compareFiles("student_output.txt", "test05.txt");

    if (marks)
    {
        cout << GREEN << "Output matches the expected result. Marks: 25/25" << RESET << endl;
        TotalMarks += 25;
    }
    else
    {
        cout << RED << "Output does not match the expected result. Marks: 0/25" << RESET << endl;
    }


    return;
}

int main()
{

    test1();
    test2();
    test3();
    test4();
    test5();

    cout<<endl<<"Your total marks are "<<TotalMarks<<"."<<endl;

    // return 0;
}