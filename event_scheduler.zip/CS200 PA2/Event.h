#include <iostream>
#include "Date.h"
#include "Time.h"

using namespace std;

class Event
{
private:
    string name, location, comment;
    Date date;
    Time start_time;
    Time end_time;

public:
    Event()
    {
        //write your code here
        name = "Unknown";
        location = "Unknown";
        comment = "none";
    }

    Event(string n, string l, string c, Date d, Time st, Time et)
    {
        //write your code here
        name = n;
        location = l;
        comment = c;
        date = d;
        start_time = st;
        end_time = et;
    }

    Event(Event &event2)
    {
        //write your code here
        name = event2.getName();
        location = event2.getLocation();
        comment = event2.getComment();
        date = event2.getDate();
        start_time = event2.getStartTime();
        end_time = event2.getEndTime();
    }

    string getName()
    {
        //write your code here
        return name;
    }

    string getLocation()
    {
        //write your code here
        return location;
    }

    string getComment()
    {
        //write your code here
        return comment;
    }

    Date getDate()
    {
        //write your code here
        return date;
    }

    Time getStartTime()
    {
        //write your code here
        return start_time;
    }

    Time getEndTime()
    {
        //write your code here
        return end_time;
    }

    void setName(const string &n)
    {
        //write your code here
        name = n;
    }

    void setLocation(const string &l)
    {
        //write your code here
        location = l;
    }

    void setComment(const string &c)
    {
        //write your code here
        comment = c;
    }

    void setDate(Date &d)
    {
        //write your code here
        date = Date(d.getDay(), d.getMonth(), d.getYear());
    }

    void setStartTime(Time &t)
    {
        //write your code here
        start_time = Time(t.getHr(), t.getMin());
    }

    void setEndTime(Time &t)
    {
        //write your code here
        end_time = Time(t.getHr(), t.getMin());
    }
    // void printEvent(){
    //     cout<<"event name: "<<name<<endl;
    //     cout<<"location: "<<location<<endl;
    //     cout<<"comment: "<<comment<<endl;
    //     cout<<"date: ";
    //     date.printDate();
    //     cout<<"start time: ";
    //     start_time.showTime();
    //     cout<<"ending time: ";
    //     end_time.showTime();
    // }

//---------------------------------------DO NOT EDIT---------------------------------------------------

    Event &operator=(const Event &event2)
    {
        
        this->name = event2.name;
        this->location = event2.location;
        this->comment = event2.comment;
        this->date = event2.date;
        this->start_time = event2.start_time;
        this->end_time = event2.end_time;

        return *this;
    }

//-----------------------------------------------------------------------------------------------------

};