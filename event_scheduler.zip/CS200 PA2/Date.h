#include <iostream>
using namespace std;

class Date
{
private:
    int day, month, year;
    string dayOfTheWeek;

public:
    // Parameterized constructor
    Date(int _day, int _month, int _year)
    {
        //write your code here
        day = _day;
        month = _month;
        year = _year;
        calculateDayOfWeek();
    }

    // Default constructor
    Date()
    {
        //write your code here
        day = 0;
        month = 0;
        year = 0;
        dayOfTheWeek = "N/A";
        calculateDayOfWeek();

    }

    // Accessor methods (getters)
    int getDay()
    {
        //write your code here
        return day;
    }

    int getMonth()
    {
        //write your code here
        return month;
    }

    int getYear()
    {
        //write your code here
        return year;
    }

    string getDayOfTheWeek()
    {
        //write your code here
        return dayOfTheWeek;
    }

    // Mutator methods (setters)
    void setDay(int _day)
    {
        //write your code here
        day = _day;
    }

    void setMonth(int _month)
    {
        //write your code here
        month = _month;
    }

    void setYear(int _year)
    {
        //write your code here
        year = _year;
    }

    void calculateDayOfWeek()
    {
        //write your code here
        int d = day;
        int m = month;
        int y = year;
        if(m==1 || m==2){
            m+=12;
            //y--;
        }
        int k = y % 100;
        int j = y / 100;

        int x = (d+(13*(m+1)/5) + k + (k / 4) + (j/4) + 5*j) % 7;
        switch(x){
        case 0:
            dayOfTheWeek = "Saturday";
            break;
        case 1:
            dayOfTheWeek = "Sunday";
            break;
        case 2:
            dayOfTheWeek = "Monday";
            break;
        case 3:
            dayOfTheWeek = "Tuesday";
            break;
        case 4:
            dayOfTheWeek = "Wednesday";
            break;
        case 5:
            dayOfTheWeek = "Thursday";
            break;
        case 6:
            dayOfTheWeek = "Friday";
            break;
        default:
            dayOfTheWeek = "N/A";
        }
    }

    // void printDate(){
    //     cout<<"date: "<<day<<" / "<<month<<" / "<<year<<" ("<<dayOfTheWeek<<")"<<endl;
    // }

//---------------------------------------DO NOT EDIT---------------------------------------------------

    Date &operator=(const Date &date2)
    {
        if (this == &date2)
        {
            return *this;
        }
        this->day = date2.day;
        this->month = date2.month;
        this->year = date2.year;
        this->dayOfTheWeek = date2.dayOfTheWeek;

        return *this;
    }

//-----------------------------------------------------------------------------------------------------

};