#include <iostream>
#include "Event.h"

using namespace std;

class DailySchedule
{
private:
    Event *scheduled_events;
    int count;
    Date date;

public:
    DailySchedule()
    {
        //write your code here
        scheduled_events = nullptr;
        count = 0;
        date;
    }

    DailySchedule(Date d)
    {
        //write your code here
        date = d;
        scheduled_events = nullptr;
        count = 0;
    }

    DailySchedule(const DailySchedule &other)
    {
        //write your code here
        date = other.date;
        count = other.count;
        if(other.scheduled_events != nullptr){
            scheduled_events = new Event[count];
            for(int i = 0; i<count ; ++i){
                scheduled_events[i] = other.scheduled_events[i];
            }
        }
        else{
            scheduled_events = nullptr;
        }
    }

    ~DailySchedule()
    {
        //write your code here
        delete[] scheduled_events;
    }

    Date getDate()
    {
        //write your code here
        return date;
    }

    Event *getEvents()
    {
        //write your code here
        return scheduled_events;
    }
    //check the date validity
    bool matchedDate(Event e){
        Date e_date = e.getDate();
        int e_day = e_date.getDay();
        if(e_day!=date.getDay()){
            return false;
        }
        return true;
    }
    //if two events conflict
    bool conflict(Event &e1, Event &e2) const{
        return !(e1.getEndTime().getHr() < e2.getStartTime().getHr() || (e1.getEndTime().getHr() == e2.getStartTime().getHr() && e1.getEndTime().getMin() <= e2.getStartTime().getMin()) || (e2.getEndTime().getHr() < e1.getStartTime().getHr() || (e2.getEndTime().getHr() == e1.getStartTime().getHr() && e2.getEndTime().getMin() <= e1.getStartTime().getMin())));
    }

    void addEvent(const Event &e){
        Event *new_scheduled_events = new Event[count + 1];
        for (int i = 0; i<count; ++i){
            new_scheduled_events[i] = scheduled_events[i];
        }
        new_scheduled_events[count] = e; //adding
        delete[] scheduled_events;
        scheduled_events = new_scheduled_events;
        count++;
    }

    void sortEvents(){
        for(int i = 0; i<count-1; ++i){
            for(int j = i+1; j<count; ++j){
                Time start1 = scheduled_events[i].getStartTime();
                Time start2 = scheduled_events[j].getStartTime();
                //Compare start times
                if(start2.getHr()<start1.getHr() || (start2.getHr() == start1.getHr() && start2.getMin() < start1.getMin())){
                    //swapping
                    Event temp = scheduled_events[i];
                    scheduled_events[i] = scheduled_events[j];
                    scheduled_events[j] = temp;
                }
            }
        }
    }

    bool compareTime(Event &e1, Event &e2){
        //return e1.getStartTime().getHr() < e2.getStartTime().getHr() || (e1.getStartTime().getHr() == e2.getStartTime().getHr() && e1.getStartTime().getMin() < e2.getStartTime().getMin());
        Time start1 = e1.getStartTime();
        Time end1 = e1.getEndTime();
        Time start2 = e2.getStartTime();
        Time end2 = e2.getEndTime();
        if(start1.getHr() > end2.getHr() || (start1.getHr() == end2.getHr() && start1.getMin() > end2.getMin())){
            return true;
        }
        return false;
    }

    void scheduleEvent(Event e)
    {
        //write your code here
        if(!matchedDate(e)){
            //cout<<"Event date is not the same. Cannot schedule the event."<<endl;
            return;
        }
        // for(int i = 0; i<count; i++){
        //     if(conflict(scheduled_events[i], e)){
        //         cout<<"Event conflict detected. Cannot schedule event."<<endl;
        //         return;
        //     }
        // }
        for (int i = 0; i < count; ++i)
        {
            if (!(compareTime(scheduled_events[i], e)) && !(compareTime(e, scheduled_events[i])))
            {
                return;
            }
        }
        addEvent(e);
        sortEvents();
    }

    void printSchedule()
    {
        //write your code here
        //header
        // for(int i = 0; i<50; ++i){
        //     cout<<"*";
        // }
        // cout<<endl;
        // cout<<"Schedule for "<<date.getDayOfTheWeek()<<", "<<date.getDay()<<"/"<<date.getMonth()<<"/"<<date.getYear()<<":"<<endl<<endl;
        // //cout<<endl;
        // for(int i = 0; i<count; i++){
        //     for(int j = 0; j<50; j++){
        //         cout<<"-";
        //     }
        //     cout<<endl;
        //     cout<<"Event: "<<scheduled_events[i].getName()<<" at "<<scheduled_events[i].getLocation()<<endl;
        //     cout<<"Start: ";
        //     scheduled_events[i].getStartTime().showTime();
        //     cout<<endl;
        //     cout<<"End: ";
        //     scheduled_events[i].getEndTime().showTime();
        //     cout<<endl;
        //     for(int j = 0; j<50; j++){
        //         cout<<"-";
        //     }
        //     cout<<endl;
        // }
        // //footer
        // for(int i = 0; i<50; i++){
        //     cout<<"*";
        // }
        // cout<<endl;

        //starting lines
        for(int i = 0; i<50; i++){
            cout<<"*";
        }
        cout<<endl;
        cout<<"Schedule for "<<date.getDayOfTheWeek()<<", "<<date.getDay()<<"/"<<date.getMonth()<<"/"<<date.getYear()<<":"<<endl<<endl;
        for(int i = 0; i<count; i++){
            for(int j = 0; j<50; j++){
                cout<<"-";
            }
            cout<<endl;
            //middle parts
            cout<<"Event: "<<scheduled_events[i].getName()<<" at "<<scheduled_events[i].getLocation()<<endl;
            cout<<"Start: ";
            if(scheduled_events[i].getStartTime().getHr()< 10){
                cout<<"0";
            }
            cout<<scheduled_events[i].getStartTime().getHr()<<":";
            if(scheduled_events[i].getStartTime().getMin()<10){
                cout<<"0";
            }
            cout<<scheduled_events[i].getStartTime().getMin()<<endl;
            cout<<"End: ";
            if(scheduled_events[i].getEndTime().getHr()< 10){
                cout<<"0";
            }
            cout<<scheduled_events[i].getEndTime().getHr()<<":";
            if(scheduled_events[i].getEndTime().getMin() < 10){
                cout<<"0";
            }
            cout<<scheduled_events[i].getEndTime().getMin()<<endl;
            for(int j = 0; j < 50; j++){
                cout<<"-";
            }
            cout<<endl;
        }
        //ending line
        for(int i = 0; i<50; i++){
            cout<<"*";
        }
    }

//---------------------------------------DO NOT EDIT---------------------------------------------------

    DailySchedule &operator=(const DailySchedule &other)
    {

        delete[] scheduled_events;

        date = other.date;
        count = other.count;

        if (other.scheduled_events != NULL)
        {
            scheduled_events = new Event[count];
            for (int i = 0; i < count; ++i)
            {
                scheduled_events[i] = other.scheduled_events[i];
            }
        }
        else
        {
            scheduled_events = NULL;
        }

        return *this;
    }
//-----------------------------------------------------------------------------------------------------

};