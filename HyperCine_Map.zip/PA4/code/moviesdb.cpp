#include <unordered_map>
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <tuple>
#include <unordered_set>
#include "../code/mystring.h"
//unordered mapping
using namespace std;

class MoviesDB {
private:
    unordered_map<string, unordered_map<string, vector<MyString>>> movietoactor; 
    unordered_map<string, vector<tuple<MyString, string>>> actortomovie; 
    unordered_map<string, int> moviePop;
    unordered_map<string, int> starPop;

public:
    const int ALPHABETICAL = 0;
    const int MOST_POPULAR = 1;

    void process_file(const string& filename){
        ifstream inputfile(filename);
        if(!inputfile){
            cerr << "Error. unable to open file." << filename << endl;
            return;
        }

        string line;
        while(getline(inputfile, line)){
            if(line.empty()){
                continue;
            }
            int last = line.find_last_of(' ');//extract
            string movie = line.substr(0, last);
            string year = line.substr(last + 1,last + 5);
            //combine
            string temp = movie + " (" + year + ")";
            moviePop[temp] = moviePop[temp] + 1;

            vector<MyString> actors;
            //actors listed under a specific movie
            while(getline(inputfile, line) && !line.empty()){
                bool isActor = false;
                for(auto& actor : actors){
                    if(line == actor.get_string()){
                        actor.set_property(actor.get_property() + 1);
                        isActor = true;
                        break;
                    }
                }
                if(!isActor){ //add if not
                    actors.push_back(MyString(line, 1)); 
                }
            }

            if(movietoactor[movie].find(year) != movietoactor[movie].end()){
                for(auto& actor : actors){
                    bool isActor = false;
                    for(auto& existing_actor : movietoactor[movie][year]){
                        if(existing_actor.get_string() == actor.get_string()){
                            existing_actor.set_property(existing_actor.get_property() + actor.get_property());
                            isActor = true;
                            break;
                        }
                    }
                    if(!isActor){
                        movietoactor[movie][year].push_back(actor);
                    }
                }
            } 
            else{
                movietoactor[movie][year] = actors;
            }
            //update
            for (const auto& actor : actors){
                starPop[actor.get_string()]++;
                if(actortomovie.find(actor.get_string()) != actortomovie.end()){
                    bool isMovie = false;
                    for(auto& movientr : actortomovie[actor.get_string()]){
                        if(get<0>(movientr).get_string() == movie && get<1>(movientr) == year){
                            get<0>(movientr).set_property(get<0>(movientr).get_property() + actor.get_property());
                            isMovie = true;
                            break;
                        }
                    }
                    if(!isMovie){
                        actortomovie[actor.get_string()].emplace_back(MyString(movie, actor.get_property()), year);
                    }
                }
                else{
                    actortomovie[actor.get_string()].emplace_back(MyString(movie, actor.get_property()), year);
                }
            }
        }
        inputfile.close();
    }

    void print_cast(string movie, const int criteria){
        if(movietoactor.find(movie) == movietoactor.end()){
            cout << movie << " does not exist in the database" << endl << endl;
            return;
        }

        vector<pair<string, vector<MyString>>> year_vec;
        for(const auto& pair : movietoactor[movie]){ //colect and sort
            year_vec.emplace_back(pair);
        }

        sort(year_vec.begin(), year_vec.end(), [](const pair<string, vector<MyString>>& a, const pair<string, vector<MyString>>& b){
            return a.first < b.first;
        });

        // for(const auto& [year, actors] : year_actors_vec){
        //     // string year = it->first;
        //     // vector<MyString> actors = it->second;
        //     if(criteria == ALPHABETICAL){
        //         sort(actors.begin(), actors.end(), [](const MyString& a, const MyString& b){
        //             return a.get_string() < b.get_string();
        for(const auto& [year, actors] : year_vec){
            if (actors.empty()) {
            cout << movie << " " << year << " has no cast in the database" << endl << endl;
            continue;
            }

            vector<MyString> sortedActors = actors; //Copy
            if(criteria == ALPHABETICAL){
                sort(sortedActors.begin(), sortedActors.end(), [](const MyString& a, const MyString& b){
                return a.get_string() < b.get_string();
                });
            }
            else if(criteria == MOST_POPULAR){
                sort(sortedActors.begin(), sortedActors.end(), [](const MyString& a, const MyString& b){
                    if(a.get_property() != b.get_property()){
                        return a.get_property() > b.get_property();
                    }
                return a.get_string() < b.get_string();
                });
        }

        cout << movie << " " << year << endl;
        for(const auto& actor : sortedActors){
            cout << actor.get_string() << endl;
        }
        cout << endl;
        }

    }

    void print_movies(string star, const int criteria){
        if(actortomovie.find(star) == actortomovie.end()){
            cout << star << " does not exist in the database" << endl << endl;
            return;
        }

        vector<tuple<MyString, string>> movies = actortomovie[star];
        if(movies.empty()){
            cout << star << " has no movies in the database" << endl << endl;
            return;
        }

        unordered_map<string, int> mpop;
        for(const auto& movie : movies){
            const string& movieName = get<0>(movie).get_string();
            mpop[movieName] += get<0>(movie).get_property();
        }

        vector<pair<string, int>> sortMovies(mpop.begin(), mpop.end());
        if(criteria == ALPHABETICAL){
            sort(sortMovies.begin(), sortMovies.end(), [](const pair<string, int>& a, const pair<string, int>& b){
                return a.first < b.first;
            });
        } 
        else if(criteria == MOST_POPULAR){
            sort(sortMovies.begin(), sortMovies.end(), [](const pair<string, int>& a, const pair<string, int>& b){
                if (a.second == b.second) {
                    return a.first < b.first;
                }
                //else{
                return a.second > b.second;
                });
        }

        cout << star << endl;
        for(const auto& movie : sortMovies){
            cout << movie.first << endl;
        }
        cout << endl;
    }

    void print_costars(string star){
        if(actortomovie.find(star) == actortomovie.end()){
            cout << "Star does not exist in the database" << endl;
            return;
        }

        unordered_map<string, unordered_map<string, vector<string>>> costarstomovies;
        for(const auto& movientr : actortomovie[star]){
            string movie_name = get<0>(movientr).get_string();
            string year = get<1>(movientr);

            for(const auto& actor : movietoactor[movie_name][year]){
                if(actor.get_string() != star){
                    costarstomovies[actor.get_string()][year].push_back(movie_name);
                }
            }
        }

        if(costarstomovies.empty()){
            cout << star << " has no costars in the database" << endl << endl;
            return;
        }

        vector<pair<string, vector<pair<string, string>>>> sortCostars;
        for(const auto& entry : costarstomovies){
            vector<pair<string, string>> movies;
            for(const auto& year_entry : entry.second){
                for(const auto& movie : year_entry.second){
                    movies.push_back({movie, year_entry.first});
                }
            }
            sort(movies.begin(), movies.end(), [](const pair<string, string>& a, const pair<string, string>& b){
                if(a.second == b.second){
                    return a.first < b.first;
                }
                return a.second < b.second;
            });
            sortCostars.push_back({entry.first, movies});
        }

        sort(sortCostars.begin(), sortCostars.end(), [](const auto& a, const auto& b){
            return a.first < b.first;
        });

        cout << star << " appeared with " << sortCostars.size() << " different stars!" << endl;
        for(const auto& entr : sortCostars){
            string costar = entr.first;
            cout << "- Appeared with " << costar << " in:" << endl;
            for(const auto& movie : entr.second){
                cout << "    o " << movie.first << " (" << movie.second << ")" << endl;
            }
        }
        cout << endl;
    }

    vector<string> get_most_popular_movies(){
        int max = 0;
        for(const auto& entr : moviePop){
            if(entr.second > max){
                max = entr.second;
            }
        }

        unordered_set<string> unique_movies;
        for(const auto& entr : moviePop){
            if(entr.second == max){
                size_t last_space = entr.first.find_last_of(' ');
                string movie = entr.first.substr(0, last_space);
                unique_movies.insert(movie);
            }
        }

        vector<string> most_popular_movies(unique_movies.begin(), unique_movies.end());
        sort(most_popular_movies.begin(), most_popular_movies.end());
        return most_popular_movies;
    }
    
    vector<string> get_most_popular_stars(){
        unordered_map<string, double> star_popularity;
        for(const auto& entr : actortomovie){
            string star = entr.first;
            int totalPop = 0;
            int totalMovies = 0;

            for(const auto& movientr : entr.second){
                totalPop += get<0>(movientr).get_property();
                totalMovies += moviePop[get<0>(movientr).get_string() + " (" + get<1>(movientr) + ")"];
            }

            if(totalMovies > 0){
                star_popularity[star] = static_cast<double>(totalPop) / totalMovies;
            }
        }

        double max_pop = 0.0;
        for(const auto& entr : star_popularity){
            if(entr.second > max_pop){
                max_pop = entr.second;
            }
        }

        vector<string> most_popular_stars;
        for(const auto& entr : star_popularity){
            if(entr.second == max_pop){
                most_popular_stars.push_back(entr.first);
            }
        }

        sort(most_popular_stars.begin(), most_popular_stars.end());
        return most_popular_stars;
    }



MoviesDB operator+=(const MoviesDB& other){
    // for(auto movie_it = other.movietoactor.begin(); movie_it != other.movietoactor.end(); ++movie_it){
    //     string movie = movie_it->first;
    //     for(auto year_it = movie_it->second.begin(); year_it != movie_it->second.end(); ++year_it){
    //         string year = year_it->first;
    //         const vector<MyString>& actors = year_it->second;

    for(const auto& [movie, year_map] : other.movietoactor){
        for(const auto& [year, actors] : year_map){
            if(movietoactor[movie].count(year)){
                for(const auto& actor : actors){
                    auto& existing_actors = movietoactor[movie][year];
                    auto it = find_if(existing_actors.begin(), existing_actors.end(),[&actor](const MyString& existing_actor){
                                          return existing_actor.get_string() == actor.get_string();
                                      });

                    if(it != existing_actors.end()){
                        it->set_property(it->get_property() + actor.get_property());
                    }
                    else{
                        existing_actors.push_back(actor);
                    }
                }
            }
            else{
                movietoactor[movie][year] = actors;
            }
        }
    }

    // for(auto actor_it = other.actortomovie.begin(); actor_it != other.actortomovie.end(); ++actor_it){
    //     string actor = actor_it->first;
    //     const vector<tuple<MyString, string>>& movies = actor_it->second;

    //     if(actortomovie.count(actor)){
    //         for(const auto& movientr : movies){
    //             bool ismovieFound = false;
    //             for(auto& existingM : actortomovie[actor])
    for(const auto& [actor, movies] : other.actortomovie){
        auto& existing_movies = actortomovie[actor];

        for(const auto& movientr : movies){
            auto it = find_if(existing_movies.begin(), existing_movies.end(), [&movientr](const auto& existingM){
                                  return get<0>(existingM).get_string() == get<0>(movientr).get_string() && get<1>(existingM) == get<1>(movientr);
                              });
            if(it != existing_movies.end()){
                int updated = get<0>(*it).get_property() + get<0>(movientr).get_property();
                get<0>(*it).set_property(updated);
            }
            else{
                existing_movies.push_back(movientr);
            }
        }
    }

    for(const auto& [movie, count] : other.moviePop){
        moviePop[movie] += count;
    }
    return *this;
}

};